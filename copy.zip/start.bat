@echo off
title YouTube LearnMode - Dev Server
echo ==================================================
echo   Starting YouTube LearnMode Prototype...
echo ==================================================
cd /d "%~dp0"
set "PATH=C:\Users\Administrator\.gemini\antigravity\scratch\node;%PATH%"
echo Opening development server on http://localhost:5173 ...
call npm run dev
pause
